
/*-------------------------------
		custom JS
-------------------------------*/


	/*----------------------------*/
// 	var slider = document.getElementById("myRange");
// 	var output = document.getElementById("demo");
// 	output.innerHTML = slider.value;

// 	slider.oninput = function() {
// 	  output.innerHTML = this.value;
// 	}

// $('#task_convert').on('shown.bs.collapse', function () {
//     $('#sidbar_contnet').animate({
//        scrollTop: $("#task_convert").offset().top
//     }, 1000);
// });




/*-------------- convert btn ------*/
$(document).ready(function(){
  $("button#convert").click(function() {
    $(".collapse").collapse('hide');

	});

});




/*---------- date -----------*/
$('.date input[type="text"]').focus('input propertychange', function() {
  var $this = $(this);
  var visible = Boolean($this.val());
  $this.siblings('#clear-dates').toggleClass('d-none', !'d-block');
}).trigger('propertychange');



$(document).ready(function(){
    $(".test").on('click', function(){
        $('head').append('<link rel="stylesheet" href="' + this.getAttribute('data-src') + '" type="text/css" />');
    });
});




  function clickStopper(e)
  {
    alert("لقد ضغطت سابقا"); // ** you can remove this line **
    e.preventDefault(); // equivalent to 'return false'
  }


let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

Date.prototype.addDays = function (days) {
    let date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}

Date.prototype.getMonthStr = function () {
    let date = new Date(this.valueOf());
    return months[date.getMonth()];
}

$('.scrollable').on('scroll', function () {
    var $e = $(this);
    //$('.scrolled').text($(this).scrollTop());
    if ($e.innerHeight() + $e.scrollTop() >= this.scrollHeight - 5) {
        var d = new Date();
        $e.append('more text added on ' + d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds() + '<br>');
    }
});


//$('.scrollable').on("change", function () {
//    mUtil.scrollTop()
//});

		

	
	
