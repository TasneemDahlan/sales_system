var Dashboard = function() {
    function() {
        if (0 != $("#m_chart_trends_stats").length) {
            var e = document.getElementById("m_chart_trends_stats").getContext("2d"),
                t = e.createLinearGradient(0, 0, 0, 240);
            t.addColorStop(0, Chart.helpers.color("#00c5dc").alpha(.7).rgbString()), t.addColorStop(1, Chart.helpers.color("#f2feff").alpha(0).rgbString());
            var a = {
                type: "line",
                data: {
                    labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April"],
                    datasets: [{
                        label: "Sales Stats",
                        backgroundColor: t,
                        borderColor: "#0dc8de",
                        pointBackgroundColor: Chart.helpers.color("#ffffff").alpha(0).rgbString(),
                        pointBorderColor: Chart.helpers.color("#ffffff").alpha(0).rgbString(),
                        pointHoverBackgroundColor: mApp.getColor("danger"),
                        pointHoverBorderColor: Chart.helpers.color("#000000").alpha(.2).rgbString(),
                        data: [20, 10, 18, 15, 26, 18, 15, 22, 16, 12, 12, 13, 10, 18, 14, 24, 16, 12, 19, 21, 16, 14, 21, 21, 13, 15, 22, 24, 21, 11, 14, 19, 21, 17]
                    }]
                },
                options: {
                    title: {
                        display: !1
                    },
                    tooltips: {
                        intersect: !1,
                        mode: "nearest",
                        xPadding: 10,
                        yPadding: 10,
                        caretPadding: 10
                    },
                    legend: {
                        display: !1
                    },
                    responsive: !0,
                    maintainAspectRatio: !1,
                    hover: {
                        mode: "index"
                    },
                    scales: {
                        xAxes: [{
                            display: !1,
                            gridLines: !1,
                            scaleLabel: {
                                display: !0,
                                labelString: "Month"
                            }
                        }],
                        yAxes: [{
                            display: !1,
                            gridLines: !1,
                            scaleLabel: {
                                display: !0,
                                labelString: "Value"
                            },
                            ticks: {
                                beginAtZero: !0
                            }
                        }]
                    },
                    elements: {
                        line: {
                            tension: .19
                        },
                        point: {
                            radius: 4,
                            borderWidth: 12
                        }
                    },
                    layout: {
                        padding: {
                            left: 0,
                            right: 0,
                            top: 5,
                            bottom: 0
                        }
                    }
                }
            };
            new Chart(e, a)
        }
    }(),
    function() {
        if (0 != $("#m_chart_trends_stats2").length) {
            var e = document.getElementById("m_chart_trends_stats2").getContext("2d"),
                t = e.createLinearGradient(0, 0, 0, 240);
            t.addColorStop(0, Chart.helpers.color("#00c5dc").alpha(.7).rgbString()), t.addColorStop(1, Chart.helpers.color("#f2feff").alpha(0).rgbString());
            var a = {
                type: "line",
                data: {
                    labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "January", "February", "March", "April"],
                    datasets: [{
                        label: "s",
                        backgroundColor: t,
                        borderColor: "#0dc8de",
                        pointBackgroundColor: Chart.helpers.color("#ffffff").alpha(0).rgbString(),
                        pointBorderColor: Chart.helpers.color("#ffffff").alpha(0).rgbString(),
                        pointHoverBackgroundColor: mApp.getColor("danger"),
                        pointHoverBorderColor: Chart.helpers.color("#000000").alpha(.2).rgbString(),
                        data: [20, 10, 18, 15, 26, 18, 15, 22, 16, 12, 12, 13, 10, 18, 14, 24, 16, 12, 19, 21, 16, 14, 21, 21, 13, 15, 22, 24, 21, 11, 14, 19, 21, 17]
                    }]
                },
                options: {
                    title: {
                        display: !1
                    },
                    tooltips: {
                        intersect: !1,
                        mode: "nearest",
                        xPadding: 10,
                        yPadding: 10,
                        caretPadding: 10
                    },
                    legend: {
                        display: !1
                    },
                    responsive: !0,
                    maintainAspectRatio: !1,
                    hover: {
                        mode: "index"
                    },
                    scales: {
                        xAxes: [{
                            display: !1,
                            gridLines: !1,
                            scaleLabel: {
                                display: !0,
                                labelString: "Month"
                            }
                        }],
                        yAxes: [{
                            display: !1,
                            gridLines: !1,
                            scaleLabel: {
                                display: !0,
                                labelString: "Value"
                            },
                            ticks: {
                                beginAtZero: !0
                            }
                        }]
                    },
                    elements: {
                        line: {
                            tension: .19
                        },
                        point: {
                            radius: 4,
                            borderWidth: 12
                        }
                    },
                    layout: {
                        padding: {
                            left: 0,
                            right: 0,
                            top: 5,
                            bottom: 0
                        }
                    }
                }
            };
            new Chart(e, a)
        }
    }()
}
jQuery(document).ready(function() {
    Dashboard.init()
});