//------------------------------------------
am4core.ready(function() {

  am4core.useTheme(am4themes_animated);
  
  // Create chart instance
  var chart = am4core.create("invoice_monthly", am4charts.XYChart);
  
  // Add data
  chart.data = [{
    "date": new Date(2022, 1),
    "Collected": 450,
    "NotCollected": 162
  }, {
    "date": new Date(2022, 2),
    "Collected": 669,
    "NotCollected": 841
  }, {
    "date": new Date(2022, 3),
    "Collected": 1200,
    "NotCollected": 199
  }, {
    "date": new Date(2022, 4),
    "Collected": 867,
    "NotCollected": 669
  }, {
    "date": new Date(2022, 5),
    "Collected": 185,
    "NotCollected": 669
  }, {
    "date": new Date(2022, 6),
    "Collected": 150,
    "NotCollected": 200
  }, {
    "date": new Date(2022, 7),
    "Collected": 1220,
    "NotCollected": 350
  },
  {
    "date": new Date(2022, 8),
    "Collected": 450,
    "NotCollected": 162
  }, {
    "date": new Date(2022, 9),
    "Collected": 669,
    "NotCollected": 841
  }, {
    "date": new Date(2022, 10),
    "Collected": 1200,
    "NotCollected": 199
  }, {
    "date": new Date(2022, 11),
    "Collected": 867,
    "NotCollected": 669
  }, {
    "date": new Date(2022, 12),
    "Collected": 185,
    "NotCollected": 669
  }];
  
  chart.colors.list = [
    am4core.color("#f4516c"),
    am4core.color("#00c5dc"),
    am4core.color("#D65DB1"),
    am4core.color("#FF9671"),
    am4core.color("#FFC75F"),
    am4core.color("#F9F871")
  ];
  
  // Create axes
  var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
  dateAxis.renderer.grid.template.location = 0;
  dateAxis.renderer.minGridDistance = 30;
  
  var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  
  // Create series
  function createSeries(field, name) {
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = field;
    series.dataFields.dateX = "date";
    series.name = name;
    series.tooltipText = "{dateX}: [b]{valueY}[/]";
    series.strokeWidth = 2;
    
    series.smoothing = "monotoneX";
    
    var bullet = series.bullets.push(new am4charts.CircleBullet());
    bullet.circle.stroke = am4core.color("#fff");
    bullet.circle.strokeWidth = 2;
    
    return series;
  }
  
  createSeries("Collected", "Collected");
  createSeries("NotCollected", "NotCollected");
  
  chart.legend = new am4charts.Legend();
  chart.cursor = new am4charts.XYCursor();
  chart.cursor.xAxis = dateAxis;
  chart.scrollbarX = new am4core.Scrollbar();
  
  
  }); // end am4core.ready()