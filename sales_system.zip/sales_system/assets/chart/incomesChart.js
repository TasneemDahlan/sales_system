am4core.useTheme(am4themes_animated);

var chart = am4core.create("IncomsChart", am4charts.PieChart);


chart.data = [{
    "manger": "Mohamed Abu Khadra",
    "num": 753
}, {
    "manger": "Ghadeer",
    "num": 398
}, {
    "manger": "Majed",
    "num": 32
}, {
    "manger": "Naje",
    "num": 721
}, {
    "manger": "Mohammed Megdad",
    "num": 144
}];



var series = chart.series.push(new am4charts.PieSeries());
series.dataFields.value = "num";
series.dataFields.category = "manger";

// this creates initial animation
series.hiddenState.properties.opacity = 1;
series.hiddenState.properties.endAngle = -90;
series.hiddenState.properties.startAngle = -90;

series.colors.list = [
    am4core.color("#845EC2"),
    am4core.color("#D65DB1"),
    am4core.color("#36a3f7"),
    am4core.color("#F9F871"),
    am4core.color("#ffb822"),
    am4core.color("#FF6F91"),
    am4core.color("#FF9671"),
    am4core.color("#FFC75F"),
    am4core.color("#ffb822")
];

chart.legend = new am4charts.Legend();