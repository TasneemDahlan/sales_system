

//------------------------------------------
am4core.ready(function() {

  am4core.useTheme(am4themes_animated);
  
  // Create chart instance
  var chart = am4core.create("invoice_chart", am4charts.XYChart);
  
  // Add data
  chart.data = [{
    "date": new Date(2022, 1),
    "Paid": 450,
    "Draft": 162,
    "PastDue": 30,
    "OutStanding": 5
  }, {
    "date": new Date(2022, 2),
    "Paid": 50,
    "Draft": 90,
    "PastDue": 30,
    "OutStanding": 5
  }, {
    "date": new Date(2022, 3),
    "Paid": 40,
    "Draft": 162,
    "PastDue": 310,
    "OutStanding": 15
  }, {
    "date": new Date(2022, 4),
    "Paid": 40,
    "Draft": 12,
    "PastDue": 3,
    "OutStanding": 50
  }];
  
  chart.colors.list = [
    am4core.color("#34bfa3"),
    am4core.color("#FF9671"),
    am4core.color("#FFC75F"),
    am4core.color("#f4516c"),
    am4core.color("#00c5dc"),
    am4core.color("#F9F871")
  ];
  
  // Create axes
  var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
  dateAxis.renderer.grid.template.location = 0;
  dateAxis.renderer.minGridDistance = 30;
  
  var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  
  // Create series
  function createSeries(field, name) {
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = field;
    series.dataFields.dateX = "date";
    series.name = name;
    series.tooltipText = "{dateX}: [b]{valueY}[/]";
    series.strokeWidth = 2;
    
    series.smoothing = "monotoneX";
    
    var bullet = series.bullets.push(new am4charts.CircleBullet());
    bullet.circle.stroke = am4core.color("#fff");
    bullet.circle.strokeWidth = 2;
    
    return series;
  }
  
  createSeries("Paid", "Paid");
  createSeries("Draft", "Draft");
  createSeries("PastDue" , "PastDue");
  createSeries("OutStanding", "OutStanding")
  
  chart.legend = new am4charts.Legend();
  chart.cursor = new am4charts.XYCursor();
  chart.cursor.xAxis = dateAxis;
  chart.scrollbarX = new am4core.Scrollbar();
  
  
  }); // end am4core.ready()