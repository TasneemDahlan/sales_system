/////////////////////////////////////
//          places                //
////////////////////////////////////
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create chart instance
var chart = am4core.create("invoices", am4charts.PieChart);

// Add data
chart.data = [ {
  "invoiceStat":"Collected",
  "value": 432
}, {
  "invoiceStat":"NotCollect",
  "value": 468
}
];

// Add and configure Series
var pieSeries = chart.series.push(new am4charts.PieSeries());
pieSeries.dataFields.category = "invoiceStat";
pieSeries.dataFields.value = "value";
pieSeries.slices.template.stroke = am4core.color("#fff");
pieSeries.slices.template.strokeWidth = 2;
pieSeries.slices.template.strokeOpacity = 1;
pieSeries.labels.template.events.on('hit', function(ev) {
  // alert('clicked on ' + ev.target.dataItem.category + ' with a value of ' + ev.target.dataItem.value);
  $('.invoice_monthly').show('slow');
});
pieSeries.slices.template.events.on('hit', function(ev) {
  $('.invoice_monthly').show('slow');
});

// This creates initial animation
pieSeries.hiddenState.properties.opacity = 1;
pieSeries.hiddenState.properties.endAngle = -90;
pieSeries.hiddenState.properties.startAngle = -90;

pieSeries.colors.list = [
    am4core.color("#00c5dc"),
    am4core.color("#f4516c"),
    am4core.color("#ffb822")
];

}); // end am4core.ready()