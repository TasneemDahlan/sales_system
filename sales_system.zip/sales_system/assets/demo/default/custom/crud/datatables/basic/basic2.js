var DatatablesBasicBasic = {
    init: function() {
        var e;
        (e = $(".m_table_1")).DataTable({
            responsive: !0,
           
            lengthMenu: [5, 10, 25, 50],
            pageLength: 10,
            language: {
                lengthMenu: "Display _MENU_"
            },
            order: [
                [1, "desc"]
            ],
            filters: true,
            info: true,
            paging: true,
            searching: true,
            serverside: true,
          
           
            //headerCallback: function(e, a, t, n, s) {
            //    e.getElementsByTagName("th")[0].innerHTML = '\n                    <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">\n                        <input type="checkbox" value="" class="m-group-checkable">\n                        <span></span>\n                    </label>'
            //},
            columnDefs: [{
                //targets: 0,
                //width: "30px",
                //className: "dt-right",
                //orderable: !1,
                // render: function(e, a, t, n) {
                //     return '\n                        <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">\n                            <input type="checkbox" value="" class="m-checkable">\n                            <span></span>\n                        </label>'
                // }
            }, {
                
            }, ]
        }), e.on("change", ".m-group-checkable", function() {
            var e = $(this).closest("table").find("td:first-child .m-checkable"),
                a = $(this).is(":checked");
            $(e).each(function() {
                a ? ($(this).prop("checked", !0), $(this).closest("tr").addClass("active")) : ($(this).prop("checked", !1), $(this).closest("tr").removeClass("active"))
            })
        }), e.on("change", "tbody tr .m-checkbox", function() {
            $(this).parents("tr").toggleClass("active")
        })
    }
};
jQuery(document).ready(function() {
    DatatablesBasicBasic.init()
});